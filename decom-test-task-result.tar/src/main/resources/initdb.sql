-- Database: arkiv
-- DROP DATABASE arkiv;

CREATE DATABASE arkiv
    WITH 
    OWNER = postgres
    ENCODING = 'WIN1252'
    LC_COLLATE = 'Norwegian_Norway.1252'
    LC_CTYPE = 'Norwegian_Norway.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;


 
-- Table: public.mappe

-- DROP TABLE public.mappe;

CREATE TABLE public.mappe
(
    mappeid SERIAL,
    sup_mappeid integer,
    tittel character varying(50) COLLATE pg_catalog."default" NOT NULL,
    offentligtittel character varying(50) COLLATE pg_catalog."default" NOT NULL,
    dokumentmedium character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT mappe_pkey PRIMARY KEY (mappeid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.mappe
    OWNER to postgres;


 -- Table: public.basisregistrering

-- DROP TABLE public.basisregistrering;

CREATE TABLE public.basisregistrering
(
    registreringsid SERIAL,
    mappeid integer NOT NULL,
    registrerings_tittel character varying(50) COLLATE pg_catalog."default" ,
    dokumenttype character varying(50) COLLATE pg_catalog."default",
    dokumentstatus character varying(50) COLLATE pg_catalog."default",
    dok_tittel character varying(50) COLLATE pg_catalog."default",
    tilknyttetregistreringsom character varying(50) COLLATE pg_catalog."default",
    dokumentnummer integer,
    CONSTRAINT reg_pkey PRIMARY KEY (registreringsid),
    CONSTRAINT basisregistrering_mappeid_fkey FOREIGN KEY (mappeid)
        REFERENCES public.mappe (mappeid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.basisregistrering
    OWNER to postgres;
    
 -- Table: public.dokumentobjekt

-- DROP TABLE public.dokumentobjekt;

CREATE TABLE public.dokumentobjekt
(
    id SERIAL,
    versjonsnummer integer NOT NULL,
    variantformat character varying(50) COLLATE pg_catalog."default" NOT NULL,
    format character varying(6) COLLATE pg_catalog."default",
    referansedokumentfil character varying(50) COLLATE pg_catalog."default" NOT NULL,
    sjekksum character varying(100) COLLATE pg_catalog."default" NOT NULL,
    sjekksumalgoritme character varying(10) COLLATE pg_catalog."default" NOT NULL,
    filstoerrelse integer NOT NULL,
    registreringsid integer NOT NULL,
    CONSTRAINT dokumentobjekt_pkey PRIMARY KEY (id),
    CONSTRAINT dokumentobjekt_fk_registreringsid_fkey FOREIGN KEY (registreringsid)
        REFERENCES public.basisregistrering (registreringsid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.dokumentobjekt
    OWNER to postgres;
