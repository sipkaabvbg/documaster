-- Index: mappe_idx

-- DROP INDEX public.mappe_idx;

CREATE UNIQUE INDEX mappe_idx
    ON public.mappe USING btree
    (mappeid, sup_mappeid)
    TABLESPACE pg_default;

-- Index: mappe_idx_titel

-- DROP INDEX public.mappe_idx_titel;

CREATE UNIQUE INDEX mappe_idx_titel
    ON public.mappe USING btree
    (tittel COLLATE pg_catalog."default")
    TABLESPACE pg_default;
    
-- Index: basisregistrering_idx

-- DROP INDEX public.basisregistrering_idx;

CREATE UNIQUE INDEX basisregistrering_idx
    ON public.basisregistrering USING btree
    (registreringsid, mappeid)
    TABLESPACE pg_default;

-- Index: basisregistrering_idxt

-- DROP INDEX public.basisregistrering_idxt;

CREATE UNIQUE INDEX basisregistrering_idx_dok
    ON public.basisregistrering USING btree
    (dok_tittel COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Index: basisregistrering_idxt_tit

-- DROP INDEX public.basisregistrering_idxt_tit;

CREATE UNIQUE INDEX basisregistrering_idxt_tittel
    ON public.basisregistrering USING btree
    (registrerings_tittel COLLATE pg_catalog."default")
    TABLESPACE pg_default;
    
    
-- Index: dokumentobjekt_idx

-- DROP INDEX public.dokumentobjekt_idx;

CREATE UNIQUE INDEX dokumentobjekt_idx
    ON public.dokumentobjekt USING btree
    (id, registreringsid)
    TABLESPACE pg_default;

-- Index: dokumentobjekt_idxr

-- DROP INDEX public.dokumentobjekt_idxr;

CREATE UNIQUE INDEX dokumentobjekt_idxr
    ON public.dokumentobjekt USING btree
    (referansedokumentfil COLLATE pg_catalog."default")
    TABLESPACE pg_default;