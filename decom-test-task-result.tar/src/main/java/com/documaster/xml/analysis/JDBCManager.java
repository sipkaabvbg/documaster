package com.documaster.xml.analysis;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.documaster.xml.analysis.api.JDBCManagerInterface;

/**
 * This class creates connection to the database and performs the data record in
 * the database
 * 
 * @author User
 *
 */
public class JDBCManager implements JDBCManagerInterface {

	private static final Logger LOGGER = Logger.getLogger(JDBCManager.class.getName());

	private String user;
	private String pass;
	private String coonectionStr;
	private String database;
	private String databaseCreateScript;
	private Connection con;

	/**
	 * 
	 * @param user
	 * @param pass
	 * @param coonectionStr
	 * @param database
	 */
	public JDBCManager(String user, String pass, String coonectionStr, String database) {
		this.user = user;
		this.pass = pass;
		this.coonectionStr = coonectionStr;
		this.database = database;
	}

	public String getDatabaseCreateScript() {
		return databaseCreateScript;
	}

	public void setDatabaseCreateScript(String databaseCreateScript) {
		this.databaseCreateScript = databaseCreateScript;
	}

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		try {
			if (con == null) {
				this.con = getConnection();
			} else {
				this.con = con;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getCoonectionStr() {
		return coonectionStr;
	}

	public void setCoonectionStr(String coonectionStr) {
		this.coonectionStr = coonectionStr;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	/**
	 * executes queries to the database
	 * 
	 * @param query
	 */
	public void insertAction(String query) {

		Statement statement = null;
		try {
			con = getConnection();
			statement = con.createStatement();
			statement.executeUpdate(query);
		} catch (SQLException ex) {
			LOGGER.log(Level.SEVERE, ex.toString(), ex);
		} finally {
			try {
				if (statement != null) {
					statement.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException ex) {
				LOGGER.log(Level.SEVERE, ex.toString(), ex);
			}
		}
	}

	/**
	 * Creates connection
	 * 
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException ex) {
			LOGGER.log(Level.SEVERE, ex.toString(), ex);
		}
		return con = DriverManager.getConnection(coonectionStr + database, user, pass);
	}

	/**
	 * Creates database and tables
	 * @param sqlObjectList
	 */
	public void ctereateDataBase(List<String> sqlObjectList) {
		String temp;
		Connection conn = null;
		Statement stmt = null;
		try {
			Class.forName("org.postgresql.Driver");

			conn = DriverManager.getConnection(coonectionStr, user, pass);

			LOGGER.info("Creating database...");
			stmt = conn.createStatement();
			temp = getDatabaseCreateScript();
			// @database@ WITH OWNER = @user@
			temp = temp.replaceFirst("@database@", database);
			temp = temp.replaceFirst("@user@", user);
			stmt.executeUpdate(temp);
			conn = getConnection();
			stmt = conn.createStatement();
			for (String sql : sqlObjectList) {
				stmt.executeUpdate(sql);
			}
			LOGGER.info("Database created successfully...");

		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}
}