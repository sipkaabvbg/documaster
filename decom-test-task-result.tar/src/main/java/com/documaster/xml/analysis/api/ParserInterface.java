package com.documaster.xml.analysis.api;

/**
 * This class sets main methods for handle XML file and executes the basic logic
 * @author User
 *
 */
public interface ParserInterface {

	/**
	 * This method processes the XML file
	 */
	public void parse();
}
