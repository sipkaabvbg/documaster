package com.documaster.xml.analysis;

/**
 * Class for constants
 * @author User
 *
 */
public class Constants {

	private Constants(){}
	
	public final static String MAPPE="mappe";
	public final static String REGISTERING=	"registrering";
	public final static String DOCUMENTBESSKRIVELSE="dokumentbeskrivelse";
	public final static String DOCUMENTOBJECT="dokumentobjekt";
	public final static String INSERT_MAPPE="INSERT INTO mappe (mappeID,sup_mappeid, tittel, offentligTittel, dokumentmedium)"
	+ "VALUES (mappeID@@, sup_mappeID@@,'tittel@@', 'offentligTittel@@', 'dokumentmedium@@')";
	
	public final static String INSERT_BASISREGISTRERING="INSERT INTO basisregistrering (registreringsID, mappeID,registrerings_tittel)"
	+ "VALUES (registreringsID@@, mappeID@@,'tittel@@')";
	
	public final static String UPDATE_BASISREGISTRERING="Update basisregistrering "
	+ "SET dokumenttype='dokumenttype@@', dokumentstatus='dokumentstatus@@',dok_tittel='tittel@@',tilknyttetRegistreringSom='tilknyttetRegistreringSom@@',"
	+ "dokumentnummer='dokumentnummer@@' where registreringsID=registreringsID@@";
	
	public final static String INSERT_DOKUMENTOBJEKT="INSERT INTO dokumentobjekt"
	+ "(versjonsnummer,registreringsID, variantformat,format,referanseDokumentfil,sjekksum,sjekksumAlgoritme,filstoerrelse)"
	+ "VALUES (versjonsnummer@@,registreringsID@@,'variantformat@@','format@@','referanseDokumentfil@@','sjekksum@@','sjekksumAlgoritme@@','filstoerrelse@@')";

	public final static String MAPPE_ID="mappeID";
	public final static String REGISTERING_ID=	"registreringsID";
	public final static String SUP_MAPPE_ID="sup_mappeID";
	public final static String NULL_VALUE="NULL";
}
