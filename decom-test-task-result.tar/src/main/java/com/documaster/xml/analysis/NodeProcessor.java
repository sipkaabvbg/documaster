package com.documaster.xml.analysis;
 
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import com.documaster.xml.analysis.api.CommandInterface;

/**
 * This is a class wrapper who keeps information about XML node.
 * All children nodes with their values are stored in Map object and also the query 
 * that will be executed to the database
 * @author User
 *
 */
public class NodeProcessor implements CommandInterface {

	private static final Logger LOGGER = Logger.getLogger( NodeProcessor.class.getName() );
	
	private String nodeName;
	private String insertQuery;
	private Map<String, String> mapNodes;
	private String tempInsert;
	private JDBCManager dbm;

	/**
	 * 
	 * @param dbm
	 */
	public NodeProcessor(JDBCManager dbm) {
		this.dbm = dbm;
	}

	/**
	 * This method implements a command  pattern functionality
	 */
	public void execute() {
		createInsert();
		dbm.insertAction(tempInsert);

	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getInsertQuery() {
		return insertQuery;
	}

	public void setInsertQuery(String insert) {
		this.insertQuery = insert;
	}

	public Map<String, String> getMapNodes() {
		if (mapNodes == null) {
			mapNodes = new HashMap<String, String>();
		}
		return mapNodes;
	}

	public void setMapNodes(Map<String, String> mapNodes) {
		this.mapNodes = mapNodes;
	}

	/**
	 *Constructs the query by replacing the parameter names with values
	 */
	public void createInsert() {
		tempInsert = insertQuery;
		for (Map.Entry<String, String> entry : mapNodes.entrySet()) {
			tempInsert = tempInsert.replaceFirst(entry.getKey(), entry.getValue());
		}
		LOGGER.info(tempInsert);
	}
}
