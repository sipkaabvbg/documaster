package com.documaster.xml.analysis.api;

import java.util.Map;

/**
 * Command interface
 * @author User
 *
 */
public interface CommandInterface {

	/**
	 * This method implements a command  pattern
	 */
	public void execute();
	
	/**
	 *Constructs the query by replacing the parameter names with values
	 */
	public void createInsert();

	/**
	 * Sets the query
	 * @param insertMappe
	 */
	public void setInsertQuery(String insertMappe);

	/**
	 * Sets the name
	 * @param mappe
	 */
	public void setNodeName(String mappe);

	/**
	 * Returns the nods with their value
	 * @return
	 */
	public Map<String, String> getMapNodes();

	/**
	 * Get the name 	
	 */
	public String getNodeName();
}
