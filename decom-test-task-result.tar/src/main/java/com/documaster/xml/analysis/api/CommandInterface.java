package com.documaster.xml.analysis.api;

/**
 * Command interface
 * @author User
 *
 */
public interface CommandInterface {

	/**
	 * This method implements a command  pattern
	 */
	public void execute();
	
	/**
	 *Constructs the query by replacing the parameter names with values
	 */
	public void createInsert();
}
