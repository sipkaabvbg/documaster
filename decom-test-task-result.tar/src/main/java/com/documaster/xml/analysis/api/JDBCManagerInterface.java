package com.documaster.xml.analysis.api;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * Interface to access databases
 * @author User
 *
 */
public interface JDBCManagerInterface {

	/**
	 * executes queries to the database
	 * @param query
	 */
	public void insertAction(String query);
	/**
	 * Creates connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException;
	/**
	 * Creates database and tables
	 * @param sqlObjectList
	 */
	public void ctereateDataBase(List<String> sqlObjectList);
	/**
	 * Set database create script
	 * @param database
	 */
	public void setDatabaseCreateScript(String database);
}
