package com.documaster.xml.analysis.api;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Interface to access databases
 * @author User
 *
 */
public interface JDBCManagerInterface {

	/**
	 * executes queries to the database
	 * @param query
	 */
	public void insertAction(String query);
	/**
	 * Creates connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException;
}
