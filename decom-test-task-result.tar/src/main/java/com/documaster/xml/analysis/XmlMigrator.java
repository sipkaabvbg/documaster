package com.documaster.xml.analysis;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays; 
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import com.documaster.xml.analysis.api.JDBCManagerInterface;
import com.documaster.xml.analysis.api.ParserInterface;

/**
 *The XmlMigrator class is an entry point for the tool, it validates the 
 *input parameters and starts the data transfer process.
 * As a parameter, a file with the following ${PATH}/init.properties name is expected.
 * @author User
 *
 */
public class XmlMigrator {
	
	private static final Logger LOGGER = Logger.getLogger( XmlMigrator.class.getName() );
	private static String xmlSourceFile;
	private static String xsdList;
	private static String user;
	private static String pass;
	private static String coonectionStr;
	private static String databaseName;
	private static List<String> sqlObjectList;
	private static Properties prop;
	private static JDBCManagerInterface jDBCManager;

	/**
	 * entry point
	 * @param args
	 */
	public static void main(String[] args) {

		ParserInterface stAXParser ;
		
		if(args.length==0){
			throw new IllegalArgumentException("init.properties file is required!");
		}
		sqlObjectList = new ArrayList<String>();
		initConfig(args[0]); 
		validate(prop);
		validateXmlAgainstXsds(xmlSourceFile);
		jDBCManager.ctereateDataBase(sqlObjectList);
		stAXParser = new StAXParser(xmlSourceFile, jDBCManager);
		stAXParser.parse();
		LOGGER.info("Process completed."); 
	}

/**
 * validates XML file against multiple XSDs.
 * @param xmlFile
 */
	public static void validateXmlAgainstXsds(String xmlFile) {

		Source[] sources;
		String[] xsdListArray;
		Validator validator;
		Schema schema;
		SchemaFactory schemaFactory;

		xsdListArray = xsdList.split(";");
		schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

		sources = new Source[xsdListArray.length];
		for (int i = 0; i < xsdListArray.length; i++) {
			sources[i] = new StreamSource(xsdListArray[i]);
		}

		try {
			schema = schemaFactory.newSchema(sources);
			validator = schema.newValidator();
			LOGGER.info("Validating " + xmlFile + " against XSDs " + Arrays.toString(sources)); 
			validator.validate(new StreamSource(new File(xmlFile)));
		} catch (Exception ex) {
			LOGGER.log( Level.SEVERE, "ERROR: Unable to validate " + xmlFile + " against XSDs " + Arrays.toString(sources), ex );
			 
		}
		 LOGGER.info("Validation process completed."); 
	}

	/**
	 * reads the properties file
	 * @param propePath
	 * @return
	 */
	public static void initConfig(String propePath) {
		FileInputStream fileInputStream;
		prop = new Properties();
		try {
			fileInputStream = new FileInputStream(propePath);
			prop.load(fileInputStream);
		} catch (IOException ex) { 
			LOGGER.log( Level.SEVERE, ex.toString(), ex );
		}
	}

	/**
	 * checks that the properties in the properties file are valid
	 * @param properties
	 */
	private static void validate(Properties properties) {

		xmlSourceFile = properties.getProperty("xml.source.file");
		isValid(xmlSourceFile);
		user = properties.getProperty("user");
		isValid(user);
		pass = properties.getProperty("pass");
		isValid(pass);
		coonectionStr = properties.getProperty("coonection.str");
		isValid(coonectionStr);
		xsdList = properties.getProperty("xsd.list");
		isValid(xsdList);
		databaseName = properties.getProperty("database.name");
		isValid(databaseName);
		
		String database= properties.getProperty("database");
		jDBCManager = new JDBCManager(user, pass, coonectionStr, databaseName);
		jDBCManager.setDatabaseCreateScript(database);
		
		 createTablesList(properties);
	}
private static void createTablesList(Properties props){
 
	 
	int i =1;
	String param="";
	while(param != null) {
	     param = (String) props.get("table"+i++);
	    if(param != null) { 
	    	sqlObjectList.add(param);
	    }   
	}
}
	/**
	 * checks that the property is valid
	 * @param xmlSourceFile
	 */
	private static void isValid(String xmlSourceFile) {
		if ((xmlSourceFile != null)) {
			if (xmlSourceFile.isEmpty()) {
				throw new IllegalArgumentException("Wrong parameter in init.properties file!");
			}
		}
	}
}
