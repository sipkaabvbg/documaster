package com.documaster.xml.analysis;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import com.documaster.xml.analysis.api.CommandInterface;
import com.documaster.xml.analysis.api.ParserInterface;

import static com.documaster.xml.analysis.Constants.MAPPE;
import static com.documaster.xml.analysis.Constants.REGISTERING;
import static com.documaster.xml.analysis.Constants.DOCUMENTBESSKRIVELSE;
import static com.documaster.xml.analysis.Constants.DOCUMENTOBJECT;
import static com.documaster.xml.analysis.Constants.INSERT_MAPPE;
import static com.documaster.xml.analysis.Constants.INSERT_BASISREGISTRERING;
import static com.documaster.xml.analysis.Constants.UPDATE_BASISREGISTRERING;
import static com.documaster.xml.analysis.Constants.INSERT_DOKUMENTOBJEKT;
import static com.documaster.xml.analysis.Constants.MAPPE_ID;
import static com.documaster.xml.analysis.Constants.REGISTERING_ID;
import static com.documaster.xml.analysis.Constants.SUP_MAPPE_ID;
import static com.documaster.xml.analysis.Constants.NULL_VALUE;

/**
 * This class handles XML file and executes the basic logic
 * @author User
 *
 */
public class StAXParser implements ParserInterface{
	private static final Logger LOGGER = Logger.getLogger( StAXParser.class.getName() );
	private String xmlFilePath;
	private Map<String, CommandInterface> mapNodes;
	private JDBCManager jDBCManager;
	
	/**
	 * 
	 * @param xmlFilePath path to XML file
	 * @param jDBCManager
	 */
	public StAXParser(String xmlFilePath,JDBCManager jDBCManager){
		this.xmlFilePath=xmlFilePath;
		this.jDBCManager=jDBCManager;
	}

/**
 * This method processes the XML file and creates objects representing XML tags.
 * When an object is created from a tag, it invokes its execut() method.
 * @param args
 */
	public  void parse() {
		int mappeOpen;
		int mappeSupperId;
		int registreringsID;
		boolean startElementMappeID;
		boolean collect;
		String foreignKey;
		String qName;
		List<CommandInterface> listNodes;
		CommandInterface nodeProcessorn;
		XMLInputFactory factory;
		XMLEventReader eventReader;
		StartElement startElement;
		XMLEvent event;
		Characters characters;
		EndElement endElement;
		
		init();
		mappeOpen = 0;
		mappeSupperId = 0;
		registreringsID = 1;
		startElementMappeID = false;
		collect = false;
		foreignKey = null;
		qName = "";
		listNodes = new ArrayList();
		nodeProcessorn = null;
		try {
			factory = XMLInputFactory.newInstance();
		    eventReader = factory.createXMLEventReader(new FileReader(xmlFilePath));
	
			while (eventReader.hasNext()) {
				event = eventReader.nextEvent();

				switch (event.getEventType()) {

				case XMLStreamConstants.START_ELEMENT:
					
					startElement = event.asStartElement();
					qName = startElement.getName().getLocalPart();
					startElementMappeID = isStartElementMappeID(startElement);
					if (mapNodes.get(qName) != null) {
						if (nodeProcessorn != null && !nodeProcessorn.getMapNodes().isEmpty()) {
							if (nodeProcessorn.getNodeName().equals(MAPPE)) {
								nodeProcessorn.execute();
								nodeProcessorn.getMapNodes().clear();
							}
						}
						nodeProcessorn = mapNodes.get(qName);
						collect = true;
					} 
					//calculate SUP_MAPPE_ID
					if (qName.equals(MAPPE)) {
						if (mappeOpen == 0) {
							mappeSupperId++;
						}
						mappeOpen++;
						if (mappeOpen > 0) {
							if (nodeProcessorn != null) {
								nodeProcessorn.getMapNodes().put(SUP_MAPPE_ID+"@@", mappeSupperId + "");
							}
						}
					}
					break;

				case XMLStreamConstants.CHARACTERS:
					characters = event.asCharacters();
					if (collect) {
						nodeProcessorn.getMapNodes().put(qName + "@@", characters.getData());
						if(qName.equals(MAPPE_ID)){					
							if(characters.getData().equals(mappeSupperId + "")){
								nodeProcessorn.getMapNodes().put(SUP_MAPPE_ID+"@@", NULL_VALUE);
							}														
						}
						if (startElementMappeID) {
							foreignKey = characters.getData();		
						}
					}
					break;

				case XMLStreamConstants.END_ELEMENT:
					endElement = event.asEndElement();
					if (endElement.getName().getLocalPart().equals(MAPPE)) {
						mappeOpen--;
					}
					if (endElement.getName().getLocalPart().equals(DOCUMENTBESSKRIVELSE)) {
						nodeProcessorn.getMapNodes().put(REGISTERING_ID+"@@", registreringsID + "");
						listNodes.add(nodeProcessorn);
						nodeProcessorn = mapNodes.get(REGISTERING);
					}
					if (endElement.getName().getLocalPart().equals(DOCUMENTOBJECT)) {
						nodeProcessorn.getMapNodes().put(REGISTERING_ID+"@@", registreringsID + "");
						listNodes.add(nodeProcessorn);
						nodeProcessorn = mapNodes.get(DOCUMENTBESSKRIVELSE);
					}
					if (endElement.getName().getLocalPart().equals(REGISTERING)) {
						nodeProcessorn.getMapNodes().put(MAPPE_ID+"@@", foreignKey + "");
						nodeProcessorn.execute();
						for (CommandInterface tempNode : listNodes) {
							tempNode.execute();
						}
						listNodes.clear();
						registreringsID++;
					}
					break;
				}
			}
		} catch (FileNotFoundException ex) {
		//	ex.printStackTrace();
			LOGGER.log( Level.SEVERE, ex.toString(), ex );
		} catch (XMLStreamException ex) {
			//e.printStackTrace();
			LOGGER.log( Level.SEVERE, ex.toString(), ex );
		}
	}

	/**
	 * This method checks if the first significant XML tag(mappeID) is reached
	 * @param startElement
	 * @return
	 */
private boolean isStartElementMappeID(StartElement startElement) {
	boolean startElementMappeID;
	if (startElement.getName().getLocalPart().equals(MAPPE_ID)) {
		startElementMappeID = true;
	} else {
		startElementMappeID = false;
	}
	return startElementMappeID;
}
	
	/**
	 * This method filled Map with wrapper classes for each significant node of the XML file.
     * For each of these classes, it determines with what SQL query the data in the database will be stored.
	 * @return
	 */
	private Map<String, CommandInterface> init() {
		CommandInterface mappe;
		CommandInterface registrering;
		CommandInterface dokumentbeskrivelse;
		CommandInterface dokumentobjekt ;
		
		mapNodes = new HashMap<String, CommandInterface>();
		mappe = new NodeProcessor(jDBCManager);
		registrering = new NodeProcessor(jDBCManager);
		dokumentbeskrivelse = new NodeProcessor(jDBCManager);
		dokumentobjekt = new NodeProcessor(jDBCManager);
		
		mapNodes.put(MAPPE, mappe);
		mappe.setNodeName(MAPPE);
		mappe.setInsertQuery(INSERT_MAPPE);

		mapNodes.put(REGISTERING, registrering);
		registrering.setNodeName(REGISTERING);
		registrering.setInsertQuery(INSERT_BASISREGISTRERING);
		
		mapNodes.put(DOCUMENTBESSKRIVELSE, dokumentbeskrivelse);
		dokumentbeskrivelse.setNodeName(DOCUMENTBESSKRIVELSE);
		dokumentbeskrivelse.setInsertQuery(UPDATE_BASISREGISTRERING);
		
		mapNodes.put(DOCUMENTOBJECT, dokumentobjekt);
		dokumentobjekt.setNodeName(DOCUMENTOBJECT);
		dokumentobjekt.setInsertQuery(INSERT_DOKUMENTOBJEKT);
		
		return mapNodes;
	}
}